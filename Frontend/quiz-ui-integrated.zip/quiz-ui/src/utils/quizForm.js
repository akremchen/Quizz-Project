export const emptyQuiz = {
    title: '',
    description: '',
    category: '',
    premium: false,
    unlockPoints: 10,
    questions: [
        {
            question: '',
            options: [
                { answer: '', correct: true },
                { answer: '', correct: false },
            ],
        },
    ],
}

export function quizToForm(quiz) {
    return {
        title: quiz.title || '',
        description: quiz.description || '',
        category: quiz.category || '',
        premium: Boolean(quiz.premium),
        unlockPoints: quiz.unlockPoints || 10,
        questions: (quiz.questions || []).map((q) => ({
            question: q.question || '',
            options: (q.options || []).map((o, index) => ({
                answer: o.answer || '',
                correct: Boolean(o.correct ?? index === 0),
            })),
        })),
    }
}

export function validateQuizForm(form) {
    if (!form.title.trim()) return 'Title is required'
    if (!form.category.trim()) return 'Category is required'
    if (form.premium && (!form.unlockPoints || Number(form.unlockPoints) < 1)) return 'Premium quizzes need a positive unlock cost'
    if (!form.questions.length) return 'At least one question is required'

    for (const [qIndex, question] of form.questions.entries()) {
        if (!question.question.trim()) return `Question ${qIndex + 1} is empty`
        if (question.options.length < 2) return `Question ${qIndex + 1} needs at least 2 options`
        if (!question.options.some((o) => o.correct)) return `Question ${qIndex + 1} needs a correct answer`

        for (const [oIndex, option] of question.options.entries()) {
            if (!option.answer.trim()) return `Option ${oIndex + 1} in question ${qIndex + 1} is empty`
        }
    }

    return null
}
