import { client } from './client.js'

const asList = (data) => Array.isArray(data) ? data : data?.notifications || data?.content || []

export const notificationApi = {
    getAll: (userId) => client.get(`/notifications/user/${userId}`).then((res) => asList(res.data)),
    getUnread: (userId) => client.get(`/notifications/user/${userId}/unread`).then((res) => asList(res.data)),
    markRead: (id) => client.patch(`/notifications/${id}/read`).then((res) => res.data),
}
