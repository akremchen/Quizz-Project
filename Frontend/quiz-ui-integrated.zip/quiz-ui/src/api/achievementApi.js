import { client, getApiError } from './client.js'

export const achievementApi = {
    ping: () => client.get('/achievement/ping').then((res) => res.data),

    getPoints: (userId) =>
        client.get(`/achievement/${userId}/points`).then((res) => res.data),

    getBadges: (userId) =>
        client.get(`/achievement/${userId}/badges`).then((res) => res.data),
}

export function getAchievementApiError(error) {
    return getApiError(error)
}
