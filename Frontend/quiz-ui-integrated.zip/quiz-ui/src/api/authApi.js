import { client } from './client.js'

export const authApi = {
    login: (payload) => client.post('/users/login', payload).then((res) => res.data),
    register: (payload) => client.post('/users/register', payload).then((res) => res.data),
    getUser: (id) => client.get(`/users/${id}`).then((res) => res.data),
}
